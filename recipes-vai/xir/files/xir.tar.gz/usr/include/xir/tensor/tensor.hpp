/*
 * Copyright 2019 Xilinx Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#pragma once

#include "xir/attrs/attrs.hpp"

#include <memory>
#include <vector>

namespace xir {

enum class DataType { INT, UINT, XINT, XUINT, FLOAT, UNKNOWN };

/**
 * @brief  XIR Tensor interface
 *
 * This class defines the basic XIR Tensor Interface.
 */
class Tensor {
 public:
  /**
   * @brief Create a Tensor instance.
   *
   * @param name The name of the Tensor.
   *
   * @param dims A vector to indicate the tensors dimensions.
   *
   * @param data_type Indicates the type of the Tensor data.
   *
   * @param bit_width Indicates the bit width of the Tensor data.
   *
   * @return A unique pointer to the new Tensor object.
   */
  static std::unique_ptr<Tensor> create(const std::string& name,
                                        const std::vector<std::int32_t>& dims,
                                        DataType data_type,
                                        const std::int32_t bit_width);

  /**
   * @brief Create a Tensor instance of the Tensor from an existing one.
   *
   * @param tensor A raw pinter to the existing instance.
   *
   * @return A unique pointer to the new Tensor object.
   */
  static std::unique_ptr<Tensor> create(const Tensor* tensor);

  /**
   * @brief Create a Tensor instance from an existing one and rename it.
   *
   * @param tensor A raw pointer to the existing Tensor.
   *
   * @param name The name of the new tensor.
   *
   * @return A unique pointer to the new Tensor object.
   */
  static std::unique_ptr<Tensor> create(const Tensor* tensor,
                                        const std::string& name);

 public:
  /**
   * @brief Get the name of the current Tensor object.
   *
   * @return The name of current Tensor object.
   */
  virtual const std::string get_name() const = 0;

  /**
   * @brief Get the bit width of the data in the current Tensor object.
   *
   * @return The bit width of the data in the current Tensor object.
   */
  virtual const std::int32_t get_bit_width() const = 0;

  /**
   * @brief Get the number of dimensions of the current Tensor object.
   *
   * @return The number of dimensions.
   */
  virtual const std::int32_t get_dim_num() const = 0;

  /**
   * @brief Get the dimension size of one specific dimension indicated by idx.
   *
   * @param idx Indicate the dimension requested.
   *
   * @return The dimension size.
   */
  virtual const std::int32_t get_dim_size(std::int32_t idx) const = 0;

  /**
   * @brief Get all the dimensions' size of the current Tensor object.
   *
   * @return A vector of the dimensions' size.
   */
  virtual const std::vector<std::int32_t> get_dims() const = 0;

  /**
   * @brief Get the number of data in the current Tensor object.
   *
   * @return The number of data.
   */
  virtual const std::int32_t get_element_num() const = 0;

  /**
   * @brief Comparing two tensors shape.
   *
   * @param tensor A raw pointer to the tensor to be compared.
   *
   * @return True if same, else false.
   */
  virtual bool is_same_size(const Tensor* tensor) const = 0;

  /**
   * @brief Get the data type of the current Tensor object.
   *
   * @return Data type.
   */
  virtual const DataType get_data_type() const = 0;

  /**
   * @brief Set the data type of the current Tensor object.
   *
   * @param type The new data type.
   */
  virtual void set_data_type(DataType type) = 0;

  /**
   * @brief Get the number of elements in the current Tensor object.
   *
   * @return Number of elements.
   */
  virtual const std::int32_t get_data_size() const = 0;

  /**
   * @brief Reshape the current Tensor object.
   *
   * @param dims The new shape.
   */
  virtual void reshape(const std::vector<std::int32_t>& dims) = 0;

  /**
   * @brief Get the Attrs object of the current Tensor object.
   *
   * @return A unique pointer to the Attrs object.
   */
  virtual std::unique_ptr<Attrs> get_attrs() const = 0;

  /**
   * @brief Set a new Attrs object to the current Tensor object.
   *
   * @param attrs A unique pointer to the new Attrs object.
   */
  virtual void set_attrs(std::unique_ptr<Attrs> attrs) = 0;

  /**
   * @brief Check the existence of the attribute indicated by key.
   *
   * @param key The attribute name.
   *
   * @return True if exist, else false.
   */
  virtual const bool has_attr(const std::string& key) const = 0;

  /**
   * @brief Get the attribute value indicated by key.
   *
   * @param key The attribute name.
   *
   * @return The attribute value.
   */
  virtual const xir::any get_attr(const std::string& key) const = 0;

  /**
   * @brief Set the attribute value indicated by <key, value> pair.
   *
   * @param key The attribute name.
   *
   * @param value The attribute value.
   *
   * @return A raw pointer to the current Tensor object.
   */
  virtual Tensor* set_attr(const std::string& key, const xir::any& value) = 0;

  /**
   * @brief Get the attribute value indicated by key.
   *
   * @param key The attribute name.
   *
   * @return The attribute value.
   */
  template <typename Dtype>
  const Dtype get_attr(const std::string& key) const {
    return xir::stdx::any_cast<Dtype>(this->get_attr(key));
  }

  /**
   * @brief Set the attribute value indicated by <key, value> pair.
   *
   * @param key The attribute name.
   *
   * @param value The attribute value.
   *
   * @return A raw pointer to the current Tensor object.
   */
  template <typename Dtype>
  Tensor* set_attr(const std::string& key, const Dtype& value) {
    this->set_attr(key, xir::any{value});
    return this;
  }

 public:
  virtual ~Tensor() = default;
};

}  // namespace xir
